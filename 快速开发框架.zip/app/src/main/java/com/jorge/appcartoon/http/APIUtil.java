package com.jorge.appcartoon.http;

/**
 * 接口工具类
 * @author：Jorge on 2015/11/11 09:39
 */
public class APIUtil {

    //推荐
    public static final String RECOMMEND="http://v2.api.dmzj.com/recommend.json";
    //Test
    public static final String BAIDU="https://www.baidu.com/";
}
